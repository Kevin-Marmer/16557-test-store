const disallowList = ['shop-information']

function store(primary, sidebar, options) {
  browser.storage.sync.set({
    "data": {
      primary_cards: primary,
      sidebar_cards: sidebar,
      options: options
    }
  }, function() {
    console.log(`%c A friendly message from Dashify `, 'background: #0095ff; color: #fff', {
      primary,
      sidebar,
      options
    });
  });
}

// turn $array of cards into storeable data
function translate(object) {
  arr = [];

  object.each(function() {
    arr.push({
      card_id: $(this)
        .find('.ui-anchor')
        .attr('id'),
      card_visible: true
    })
  })

  return arr
}


// get card of id
function getCard(id) {
  if ($(id).attr('id') === 'restricted-payment-accounts') {
    return $('div.ui-card');
  }
  return $(id).closest('.ui-card');
}

function findNew(current, saved, bookmark) {
  $.each(current, function(i, currentCard) {
    var found = false;
    $.each(saved, function(i, savedCard) {
      if (currentCard.card_id == savedCard.card_id) {
        found = true;
      }
    })

    if (!found) {
      if (bookmark) {
        newBookmark(currentCard.card_id, 'new');
      }
      saved.unshift(currentCard);
    }
  })

  return saved
}

function filter(data) {
  return data.filter(function() {
    if ($(this).find('.ui-anchor').length > 0) {
      if ($(this).find('.ui-anchor').attr('id').length > 1) {
        return disallowList.indexOf($(this).find('.ui-anchor').attr('id')) == -1
      }
    }
  })
}

browser.storage.sync.get(["data"], function(obj) {

  if (obj.data) {
    var data = obj.data;
    var primaryCards = data.primary_cards;
    var sidebarCards = data.sidebar_cards;

    function prepCard(id, card, hidden, position, bookmark) {
      card.addClass('dashify__sorted');
            
      if (hidden) {
        if (bookmark) {
          newBookmark(id, 'hidden');
        }
        card.hide();
      } else {
        if (bookmark) {
          newBookmark(id);
        }
        card.css('order', `${position}`);
      }
    }

    function cycleCards(array, bookmark) {
      for (activeCard in array) {
        var active = array[activeCard];
        var card = $(`#${active.card_id}`);
        var position = activeCard++;

        if (!!card.length) {
          prepCard(
            active.card_id,
            getCard(card),
            (active.card_visible ? false : true),
            position,
            bookmark
          );
        }
      }
    }

    cycleCards(primaryCards, true);
    cycleCards(sidebarCards, false);

    const mutationTargetElement = document.querySelector('.ui-layout__sections');

    const observer = new MutationObserver(function(mutations) {
      mutations.forEach(function() {
        cycleCards(primaryCards, false);
        cycleCards(sidebarCards, false);
        updateSettings()
      });
    });

    const mutationConfig = {
      childList: true,
      subtree: true
    };

    observer.observe(mutationTargetElement, mutationConfig);

    function updateSettings() {
      var currentInternalPrimaryCards = filter($('.ui-layout__section--primary section.ui-card:not(:first-child, .internal-note), .ui-layout__section--primary div.ui-card'));
      var currentInternalSidebarCards = filter($('.ui-layout__section--secondary > div > .ui-card:not(:first-child)'));

      var primaryUpdate = (
        filter($('.ui-layout__section--primary > div > .ui-card:not(.dashify__sorted)')).length > 0 ? true : false
      ),
      sidebarUpdate = (
        filter($('.ui-layout__section--secondary > div > .ui-card:not(.dashify__sorted)')).length > 0 ? true : false
      )

      if (primaryUpdate && sidebarUpdate) {
        store(findNew(translate(currentInternalPrimaryCards), primaryCards, true), findNew(translate(currentInternalSidebarCards), sidebarCards, false), data.options);
      } else if (primaryUpdate) {
        store(findNew(translate(currentInternalPrimaryCards), primaryCards, true), sidebarCards, data.options);
      } else if (sidebarUpdate) {
        store(primaryCards, findNew(translate(currentInternalSidebarCards, false), sidebarCards), data.options);
      }
    };

    updateSettings()

  } else {
    var currentInternalPrimaryCards = filter($('.ui-layout__section--primary  section.ui-card:not(:first-child, .internal-note), .ui-layout__section--primary div.ui-card'));
    var currentInternalSidebarCards = filter($('.ui-layout__section--secondary > div > .ui-card:not(:first-child)'));

    newBookmark('Initialized!', 'init');
    store(translate(currentInternalPrimaryCards), translate(currentInternalSidebarCards), {});
  }


});
