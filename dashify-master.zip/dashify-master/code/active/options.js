// for tracking events, but only send on save
var tracking = {};

var customOptions = {
  auditEvents: {
    id: 'auditEvents',
    title: 'Categorize audit events',
    description: `Categorize <a href="https://screenshot.click/be-super-nice-7mmxw.png" target="_blank">audit events</a> into neatly packed folders and a modal showing entries. Make sure the audit events card is activated in Main cards!`,
  },
  plusNotification: {
    id: 'plusNotification',
    title: 'Plus Specialist Notifications',
    description:
      'Displays a <a href="https://screenshot.click/i-draw-really-bad-arrows-eyswo.jpg" target="_blank">notification</a> on the internal dashboard if the shop is Segmented Plus or Embassy.',
  },
};

var toast = $('<span/>', {
  class: 'Polaris-Button save-toast',
}).text('Click to save pending changes');

$(() => {
  toast.appendTo('#bg');
});

function pendingChanges(on) {
  if (on) {
    $('.save-toast').addClass('active');
  } else {
    setTimeout(() => {
      $('.save-toast').removeClass('active');
    }, 500);
  }
}

// used to check if an element is within x, while not moving the focus
$.fn.within = function(a) {
  return this.filter(function() {
    return !!$(this).closest(a).length;
  });
};

// return true/false if checkbox is checked instead of on/off
function getStatus(element) {
  if (element.is(':checked')) {
    return true;
  }
  return false;
}

// store data for internalDash.js
function store(data) {
  console.log(
    `%c A friendly message from Dashify `,
    'background: #0095ff; color: #fff',
    data
  );
  browser.storage.sync.set({
    data: data,
  });
}

// get data here instead of below for exporting settings
function get() {
  var data = {
    primary_cards: [],
    sidebar_cards: [],
    options: {},
  };

  // get primary cards
  $('#primary tbody > .card').each((i, element) => {
    var element = $(element);
    data.primary_cards.push({
      card_id: element.attr('id'),
      card_visible: getStatus(element.find('.hidden')),
    });
  });

  // get sidebar cards
  $('#sidebar tbody > .card').each((i, element) => {
    var element = $(element);
    data.sidebar_cards.push({
      card_id: element.attr('id'),
      card_visible: getStatus(element.find('.hidden')),
    });
  });

  // get options
  for (var option in customOptions) {
    data.options[option] = {
      option_name: customOptions[option].title,
      option_status: getStatus($('#' + option).find('.enabled')),
    };
  }

  return data;
}

// presets
$(document).on('click', '.presets button', function() {
  console.log(window.presets, $(this).attr('id'));
  var preset = window.presets[$(this).attr('id')];
  $('input').prop('checked', false);

  function cycle(context, prepend) {
    for (setting in preset[context]) {
      var card = $(`#${setting.replaceAll('_', '-')}`);
      if (prepend) {
        card.prependTo($(`#${context}`));
      }

      card.find('input').prop('checked', true);
    }
  }

  cycle('primary', true), cycle('sidebar', true), cycle('options', false);
});

const importTrigger = () => {
  $('.import').on('click', () => {
    console.log($('#import-upload'));
    $('#import-upload').click();
    $('#import-upload').change(() => {
      var file = $('#import-upload')[0].files[0];
      if (file) {
        var reader = new FileReader();
        reader.readAsText(file, 'UTF-8');
        reader.onload = function(evt) {
          var data = JSON.parse(evt.target.result);
          console.log(data);

          browser.storage.sync.set({
            data: {
              primary_cards: data.primary_cards,
              sidebar_cards: data.sidebar_cards,
              options: data.options,
            },
          });

          window.location.reload(false);
        };
        reader.onerror = function(evt) {
          alert('Error reading file.');
        };
      }
    });
  });
}

$(document).ready(() => {
  browser.storage.sync.get(['data'], obj => {
    if (obj.data !== undefined) {
      console.log('yes');
      $('#has_data').removeClass('hidden');
      var data = obj.data;

      function setCards(context, settings) {
        var contextTable = $(`#${context} tbody`);
        contextTable.html('');
        for (card in settings[`${context}_cards`]) {
          var card = settings[`${context}_cards`][card];
          contextTable.append(
            $('<tr/>', {
              class: 'card',
              id: card.card_id,
            })
              .append(
                $('<td/>').append(
                  $('<input/>', {
                    class: 'hidden',
                    name: 'checkbox',
                    type: 'checkbox',
                    checked: card.card_visible,
                  })
                )
              )
              .append(
                $('<td/>', {
                  class: 'name Polaris-TextStyle',
                }).text(card.card_id.replace(/\-/g, ' '))
              )
              .append(
                $('<span/>', {
                  class: 'x',
                }).text('x')
              )
          );
        }
      }

      setCards('primary', data), setCards('sidebar', data);

      var optionsTable = $('#options');
      for (option in customOptions) {
        var option = customOptions[option];

        optionsTable.append(
          $('<tr/>', {
            id: option.id,
            class: 'option-container card',
          })
            .append(
              $('<td/>', {
                class: 'option-header',
              })
                .append(
                  $('<input/>', {
                    type: 'checkbox',
                    checked:
                      data.options[option.id] &&
                      data.options[option.id].option_status
                        ? true
                        : false,
                    class: 'option-click-event enabled',
                  })
                )
                .append(
                  $('<td/>', {
                    class: 'Polaris-TextStyle',
                  }).text(option.title)
                )
            )
            .append(
              $('<td/>', {
                class: 'option-description',
                colspan: '2',
              }).append($('<p/>').html(option.description))
            )
        );
      }

      // export data
      $('#export').on('click', () => {
        var a = document.createElement('a');

        var file = new Blob([JSON.stringify(get())], {
          type: 'text/plain',
        });
        a.href = URL.createObjectURL(file);
        a.download = 'Dashify.json';
        a.click();
      });

      importTrigger();

      $('#options input').on('click', function() {
        tracking[$(this).attr('id')] = $(this).prop('checked');
      });

      $('.card input').on('click', function() {
        tracking[
          $(this)
            .closest('.card')
            .attr('id')
        ] = $(this).prop('checked');
      });

      // pending events
      $(document).on('click', '[type="checkbox"], .preset', () => {
        pendingChanges(true);
      });

      $('.x').on('click', function() {
        if (!$(this).hasClass('confirm')) {
          $(this).addClass('confirm');
        } else {
          $(this)
            .closest('.card')
            .remove();
          pendingChanges(true);
        }
      });

      $('.sortable').sortable({
        update: () => {
          pendingChanges(true);
        },
      });
      $('.sortable').disableSelection();

      // un/check buttons
      $('.action').on('click', function() {
        pendingChanges(true);
        var _this = $(this);
        $(`#${_this.attr('data-section')} input`).prop(
          'checked',
          _this.attr('data-action') == 'true' ? true : false
        );
      });

      // reset to default settings
      $('#reset').on('click', function() {
        browser.runtime.sendMessage({
          track: ['send', 'event', `Options`, 'reset', true],
        });
        if ($(this).text() == 'Are you sure?') {
          browser.storage.sync.remove(['data'], () => {
            $('#reset').text('Refresh this page');
            pendingChanges(false);
          });
        } else {
          $(this).text('Are you sure?');
        }
      });

      // save the data
      $(document).on('click', '#save, .save-toast', () => {
        // track all the final options
        pendingChanges(false);
        $.each(tracking, (title, value) => {
          browser.runtime.sendMessage({
            track: ['send', 'event', `Options`, title, value],
          });
        });

        // display that Dashify is saving
        var save_button = $('#save'),
          originalText = $('#save').text();
        save_button.text('Saved');
        setTimeout(() => {
          save_button.text(originalText);
        }, 3000);

        // send the data!
        store(get());
      });
    } else {
      console.log('no');
      $('#no_data').removeClass('hidden');
      importTrigger();
    }
    // console.log({obj});
  });
});
