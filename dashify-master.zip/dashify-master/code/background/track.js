(function(i, s, o, g, r, a, m) {
  i["GoogleAnalyticsObject"] = r;
  (i[r] =
    i[r] ||
    function() {
      (i[r].q = i[r].q || []).push(arguments);
    }),
    (i[r].l = 1 * new Date());
  (a = s.createElement(o)), (m = s.getElementsByTagName(o)[0]);
  a.async = 1;
  a.src = g;
  m.parentNode.insertBefore(a, m);
})(
  window,
  document,
  "script",
  "https://www.google-analytics.com/analytics.js",
  "ga"
); // Note: https protocol here

ga("create", "UA-113381414-8", "auto");
ga("set", "checkProtocolTask", function() {}); // Removes failing protocol check. @see: http://stackoverflow.com/a/22152353/1958200
ga("require", "displayfeatures");

var lastID;
browser.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  if (message.track) {
    ga(...message.track);
  } else if (message.url) {
    var rega = /.*shops\/(\d+)/g;
    if (message.url.indexOf("/services/internal/shops") != -1) {
      var match = rega.exec(message.url);
      if (lastID != match[1]) {
        ga("send", "pageview", {
          page: "internal-dash",
          title: match[1]
        });
        lastID = match[1];
      }
    }
  }
});
