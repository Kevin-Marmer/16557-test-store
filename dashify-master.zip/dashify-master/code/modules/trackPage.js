$(function() {
  browser.runtime.sendMessage({
    url: window.location.href
  });
})
