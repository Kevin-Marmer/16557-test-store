// @goat

function toWord(slug) {
  return slug.replace(/\-/g, ' ');
}

function hashCode(str) {
  // java String#hashCode
  let hash = 0;
  for (let i = 0; i < str.length; i += 1) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash);
  }
  return hash;
}

function intToARGB(i) {
  return (
    ((i >> 24) & 0xff).toString(16) +
    ((i >> 16) & 0xff).toString(16) +
    ((i >> 8) & 0xff).toString(16) +
    (i & 0xff).toString(16)
  );
}

// Get bookmark name
const getName = (ref, slugInput) => {
  let displayName = slugInput;

  if (ref === 'new') {
    displayName = `${slugInput} (new)`;
  } else if (ref === 'top') {
    displayName = `Top of page`;
  }
  return toWord(displayName);
};

// Generate a new bookmark
const bookmarkGenerator = (referrer, slug, color) => {
  return $('<li>', {
    class: `ui-nav__item ui-nav__item--parent ${
      referrer === 'hidden' ? 'dashify__hidden-bookmark' : ''
    }`,
    'data-card-target': slug,
  }).append(
    $('<a/>', {
      href: referrer === 'init' ? '#' : `#${slug}`,
      class: 'ui-nav__link ui-nav__link--parent',
    })
      .append(
        $('<span/>', {
          class: `dashify icon`,
          'data-icon': referrer === 'top' ? '▲' : slug.charAt(0),
          style: `--icon-color: #${
            color.length > 7 ? color.substring(0, 6) : color
          };`,
        })
      )
      .append(
        $('<span/>', {
          class: 'ui-nav__label ui-nav__label--parent lightweight',
        }).text(getName(referrer, slug))
      )
  );
};

function newCategory(name, subtext, topLink) {
  const bookmarksList = $('<ul/>', {
    class: 'dashify ui-nav__group ui-nav__group--parent',
  });

  $('.ui-nav')
    .append(
      $('<hr/>', {
        class: 'dashify',
      })
    )
    .append(bookmarksList);

  const marker = $('<li>', {
    class:
      'tracking__bookmark ui-nav__item ui-nav__item--parent ui-nav__link ui-nav__link--parent',
  })
    .append(
      $('<span/>', {
        class: `dashify icon goat`,
      })
    )
    .append(
      $('<span/>', {
        class: 'ui-nav__label ui-nav__label--parent',
      })
        .text(name)
        .append(
          $('<small/>', {
            class: 'ml',
          }).text(subtext)
        )
    );

  bookmarksList.append(marker);
  let topLinkMarkup = false;
  if (topLink) {
    topLinkMarkup = $(bookmarkGenerator('top', '', '#bbb'));
    bookmarksList.append(topLinkMarkup);
  }
  return {
    category: bookmarksList,
    marker,
    topLinkMarkup,
  };
}

const bookmarks = newCategory('Jump to', 'Click to jump', true);

let hiddenBookmarks;

function newBookmark(slug, referrer) {
  const color = intToARGB(hashCode(slug));
  const bookmark = bookmarkGenerator(referrer, slug, color);

  bookmark.on('click', () => {
    browser.runtime.sendMessage({
      track: ['send', 'event', 'Actions', 'Jump to section'],
    });
  });
  switch (referrer) {
    case 'new':
      if (bookmarks.topLinkMarkup) {
        bookmark.insertAfter(bookmarks.topLinkMarkup);
      } else {
        bookmark.insertAfter(bookmarks.marker);
      }
      break;
    case 'hidden':
      if (hiddenBookmarks === undefined) {
        hiddenBookmarks = newCategory('Hidden cards', 'Click to show', false);
      }

      bookmark.on('click', function() {
        const jump = $(this);
        if (jump.hasClass('show')) {
          getCard(`#${jump.attr('data-card-target')}`).hide();
          jump.removeClass('show');
        } else {
          getCard(`#${jump.attr('data-card-target')}`).show();
          jump.addClass('show');
        }
      });
      hiddenBookmarks.category.append(bookmark);
      break;
    default:
      bookmarks.category.append(bookmark);
  }
}
