// @rt

browser.storage.sync.get(['data'], obj => {
  if (obj.data && obj.data.options.plusNotification) {
    if (obj.data.options.plusNotification.option_status) {
      const appendFlag = flag => {
        $('.ui-top-bar .ui-top-bar__item--fill').text('').append(`
        <div class="dashify__embassy-notifications">
          <h3>This is a ${flag.title} shop.</h3>
          <p>${flag.message}</p>
        </div>`);
      };

      const flags = {
        Embassy: {
          title: 'Large Merchant/Embassy',
          message:
            'For troubleshooting assistance, reference the <a href="https://docs.google.com/spreadsheets/d/1IiTPFUsU3ysoV24W3TkJVWsQqDcRe8MKnOmgVZ7AlvM/edit?usp=sharing" target="_blank" rel="noreferrer nofollow">Embassy Triage Chart</a>',
        },
        'Segmented Plus': {
          title: 'Self-Drive Plus',
          message:
            'For troubleshooting assistance, reference the <a href="https://docs.google.com/spreadsheets/d/1IiTPFUsU3ysoV24W3TkJVWsQqDcRe8MKnOmgVZ7AlvM/edit?usp=sharing" target="_blank" rel="noreferrer nofollow">Plus Specialist Triage Chart</a>.',
        },
        'Dedicated Plus': {
          title: 'Dedicated Plus',
          message:
            'For troubleshooting assistance, reference the <a href="https://docs.google.com/spreadsheets/d/1IiTPFUsU3ysoV24W3TkJVWsQqDcRe8MKnOmgVZ7AlvM/edit?usp=sharing" target="_blank" rel="noreferrer nofollow">Plus Specialist Triage Chart</a>',
        },
      };

      $(() => {
        let flagged = false;
        const tags = getCard('#tags');

        // Replaced for/in
        // XXX doesn't have the break option present in the for/in loop - is this required?
        Object.entries(flags).forEach(flag => {
          console.log(flag);
          const checkbox = tags.find(`[value="${flag}"]`);
          if (checkbox.length && checkbox.is(':checked')) {
            if (flag === 'Segmented Plus') {
              // detect self-drive
              const msm = $(
                '#shop_assistant_merchant-success-manager_employee_id'
              );
              if (msm.val() === '') {
                appendFlag(flags[flag]);
                flagged = true;
              }
            } else {
              // detect embassy
              appendFlag(flags[flag]);
              flagged = true;
            }
          }
        });
        console.log(flagged);
        // End of replacement code

        // Replaced code
        // for (let flag in flags) {
        //   const checkbox = tags.find(`[value="${flag}"]`);

        //   if (checkbox.length && checkbox.is(':checked')) {
        //     if (flag === 'Segmented Plus') {
        //       // detect self-drive
        //       const msm = $(
        //         '#shop_assistant_merchant-success-manager_employee_id'
        //       );
        //       if (msm.val() === '') {
        //         appendFlag(flags[flag]);
        //         flagged = true;
        //       }
        //     } else {
        //       // detect embassy
        //       appendFlag(flags[flag]);
        //       flagged = true;
        //     }
        //     break;
        //   }
        // }
        // console.log(flagged);
        // End of replaced code

        const planTitle = $('#plan')
          .parent()
          .text();

        if (planTitle.includes('Shopify Plus Plan') && !flagged) {
          // detect dedicated plus
          const msmText = $(
            '#shop_assistant_merchant-success-manager_employee_id'
          ).val();
          if (msmText.length > 0) appendFlag(flags['Dedicated Plus']);
        }
      });
    }
  }
});
