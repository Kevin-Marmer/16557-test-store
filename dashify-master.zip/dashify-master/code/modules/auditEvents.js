// @goat
entries = {};

browser.storage.sync.get(["data"], function(obj) {
  if (obj.data && obj.data.options.auditEvents) {
    if (obj.data.options.auditEvents.option_status) {
      function createFolders() {
        function createFolder(who, slug) {
          $("#audit-events-table-body").append(
            $("<tr/>", {
              class: "ui-data-table__row new"
            })
              .append(
                (td_a = $("<td/>", {
                  class: "ui-data-table_cell"
                }).text(who))
              )
              .append(
                $("<td/>", {
                  class: "ui-data-table_cell"
                })
              )
              .append(
                $("<td/>", {
                  class: "ui-data-table_cell"
                }).append(
                  $("<a/>", {
                    class: "btn show-events",
                    id: slug
                  }).text(`Show events (${entries[slug].length})`)
                )
              )
          );
        }

        $.each(entries, function(who, folder) {
          if (who.length > 1) {
            createFolder(folder[0].who, who);
          }
        });
      }

      function slug(text) {
        return text
          .toString()
          .toLowerCase()
          .replace(/\s+/g, "-") // Replace spaces with -
          .replace(/[^\w\-]+/g, "") // Remove all non-word chars
          .replace(/\-\-+/g, "-") // Replace multiple - with single -
          .replace(/^-+/, "") // Trim - from start of text
          .replace(/-+$/, ""); // Trim - from end of text
      }

      var card = getCard("#audit-events");
      var loadMore = card.find(".ui-button");

      var header = card.find(".ui-card__header .ui-heading");
      header.text(header.text() + " (loading)");

      function getEntries(object) {
        $.each(object, function(i, v) {
          var what = $(v)
            .find(".ui-data-table__cell")
            .eq(0)
            .text()
            .trim();
          var who = $(v)
            .find(".ui-data-table__cell")
            .eq(1)
            .text()
            .trim();
          var when = $(v)
            .find(".ui-data-table__cell")
            .eq(2)
            .text()
            .trim();

          if (!(slug(who) in entries)) {
            // haven't seen this one before, add it in
            entries[slug(who)] = [
              {
                what: what,
                who: who,
                when: when
              }
            ];
          } else {
            // slug already in there
            entries[slug(who)].push({
              what: what,
              who: who,
              when: when
            });
          }
        });
      }

      function setupEnvironment() {
        var header = card
          .find(".ui-data-table__header")
          .find(".ui-data-table__row");
        header
          .find("th")
          .eq(0)
          .text("Who");
        header
          .find("th")
          .eq(1)
          .text("");
        header
          .find("th")
          .eq(2)
          .text("Show");

        function createEntry(where, what, when) {
          where.append(
            $("<tr/>", {
              class: "ui-data-table__row new"
            })
              .append(
                $("<td/>", {
                  class: "ui-data-table__cell"
                }).text(what)
              )
              .append(
                $("<td/>", {
                  class: "ui-data-table__cell"
                }).text(when)
              )
          );
        }

        var modal = `
          <div class="modal" id="eventsModal">
             <div class="modal-content" style="width:80%;">
               <span style="float:left;padding:20px;font-weight:300;font-size:1.5em;" class="show-events__header"></span>
               <span class="show-events__close" style="color:rgb(170,170,170);float:right;font-size:28px;font-weight:bold;">&times;</span>
               <div class="ui-data-table__scroll-wrapper">
                <table class="ui-data-table ui-data-table--scroll">
                  <thead class="ui-data-table__header">
                    <tr class="ui-data-table__row">
                      <th class="ui-data-table__cell ui-data-table__cell--header" scope="col">
                        What
                      </th>
                      <th class="ui-data-table__cell ui-data-table__cell--header" scope="col">
                        When
                      </th>
                    </tr>
                  </thead>
                  <tbody class="ui-data-table__body" id="audit-events__container">
                  </tbody>
                </table>
              </div>
             </div>
           </div>`;
        $("#body-content").append(modal);

        $(document).on("click", ".show-events", function() {
          var container = $("#audit-events__container");

          var showWhat = $(this).attr("id");
          var obj = entries[showWhat];
          $(".show-events__header").text(obj[0].who);
          container.html("");
          $.each(obj, function(i, entry) {
            createEntry(container, entry.what, entry.when);
          });
          $("#eventsModal").show();
        });

        $(".show-events__close").on("click", function() {
          $("#eventsModal").hide();
        });

        var header = card.find(".ui-card__header .ui-heading");
        header.text(header.text().replace(" (loading)", ""));
      }

      $('#audit-events-load-more').remove();
      $('#audit-events-table-body .ui-data-table__row').remove();

      const get_events = async () => {
        const response = await fetch(
          `${window.location.origin}${
            window.location.pathname
          }/audit_events?event_offset=0&event_limit=999999`
        );
        const data = await response.text();
        return $.parseHTML(data);
      };

      const init = async () => {
        const all_events = await get_events();
        getEntries(all_events);
        setupEnvironment();
        createFolders();
      };

      init();
    }
  }
});
