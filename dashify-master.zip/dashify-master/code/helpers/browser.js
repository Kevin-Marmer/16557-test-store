window.browser = (() => {
  return window.browser || window.chrome;
})();
